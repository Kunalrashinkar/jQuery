$(document).ready(function() {
	console.log("this is also my first code")
	
	$("#btn2").click(function(){
		
		
		// val function
		
		//val to click kru or value get ho jaye
	    /* let v=	$("#f").val()
		console.log("value is " + v)*/
		
		// val to click kru or value set ho jaye
		
		//$("#f").val("this is done Using val function")
		
		
		// TEXT FUNCTION
		
		// HTML element k text ko nikal k kam aata h
		 /*let t = $("#content").text();
		 console.log(t)*/
		
		//dynamically text ko set krna h 
		//$("#content").text("<b>This is new ID</b>");
		
		// HTML() 
		//$("#content").html("<b>This is new ID</b>");
		
		//image
		
	/*let s=$(".image").attr("src")
	
	console.log(s)*/
		
		
		//change the image
		$(".image").attr("src","https://static.vecteezy.com/packs/media/vectors/term-bg-1-3d6355ab.jpg")
		
	})

})	