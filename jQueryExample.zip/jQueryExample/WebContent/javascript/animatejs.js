$(document).ready(function() {
	console.log("this is also my first code")

	$('#btn1').click(function() {
		// $("#container").animate({width:"300",
		// height:"200",opacity:"0.5"},3000,function(){

		// for relative height means badne k bad hi badlegi
		// $("#container").animate({width:"+=300",
		// height:"+=200"},3000,function(){

		$("#container").animate({width : "300",height : "200",opacity : "0.5",
			left : "250px"
		}, 3000, function() {

			$("#container").animate({ borderRadius:"20px" ,left : "0",height : "100",width : "100",
				opacity : "1"

			})

		})
	})
})