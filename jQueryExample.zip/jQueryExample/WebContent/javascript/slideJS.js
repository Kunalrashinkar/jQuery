$(document).ready(function(){
    console.log("this is also my first code")
    
    
    $('#btn2').click(function(){
      $("#container").slideUp(3000,function(){
    		
    		alert("Slide up done....")
    		
    	})
    })
    $('#btn1').click(function(){
      $("#container").slideDown(3000,function(){
    		
    		alert("Slide down done....")
    		
    	})
    })
    
    $('#btn3').click(function(){
      $("#container").slideToggle(3000,function(){
    		
    		alert("Slide Toggle done....")
    		
    	})
    })
    
})