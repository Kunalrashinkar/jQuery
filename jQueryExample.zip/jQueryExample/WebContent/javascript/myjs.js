$(document).ready(function(){
    console.log("this is also my first code")
    
    //effect
    //hide and show div ke container k liye
    
    $('#btn1').click(function(){
      //btn-click	
    	//$("#container").hide()
    	// $('#container').toggle();
    	$("#container").fadeOut(5000,function(){
    		
    		alert("Fade out done....")
    		
    	})
    })
    
    $('#btn2').click(function(){
      //btn-click	
    	//$("#container").show()
    	$("#container").fadeIn(3000,function(){
    		
    		alert("fade in done....")
    		
    	})
    })
    
     $('#btn3').click(function(){
      
    	$("#container").fadeToggle(3000,function(){
    		
    		alert("toggle done....")
    		
    	})
    })
    
    $('#btn4').click(function(){
      
    	$("#container").fadeTo(300,0.5,function(){
    		
    		alert("fade  To done....")
    		
    	})
    })
    
})


